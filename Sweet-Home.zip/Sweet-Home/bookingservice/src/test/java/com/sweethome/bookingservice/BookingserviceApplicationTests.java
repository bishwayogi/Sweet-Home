package com.sweethome.bookingservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookingserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
