package com.sweethome.bookingservice.Service;

import com.sweethome.bookingservice.Model.PaymentRequest;

public interface PaymentService {
    Long processPayment(PaymentRequest paymentRequest);
}


