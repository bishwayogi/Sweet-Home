package com.sweethome.bookingservice.Model;

public class InvalidBookingIdException extends Exception {
    public InvalidBookingIdException(String message) {
        super(message);
    }
}

