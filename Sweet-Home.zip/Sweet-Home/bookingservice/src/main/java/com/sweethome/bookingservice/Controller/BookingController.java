package com.sweethome.bookingservice.Controller;

import com.sweethome.bookingservice.Model.*;
import com.sweethome.bookingservice.Service.BookingService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.Random;

@RestController
@RequestMapping("/hotel")
public class BookingController {

    @Autowired
    private BookingService bookingService;


    @PostMapping("/booking")
    public ResponseEntity<BookingEntity> bookRooms(@RequestBody BookingRequest bookingRequest) {
        BookingEntity bookingInfo = bookingService.bookRooms(bookingRequest);
        return new ResponseEntity<>(bookingInfo, HttpStatus.CREATED);
    }

    @PostMapping("/booking/{bookingId}/transaction")
    public ResponseEntity<?> makeTransaction(@PathVariable Long bookingId, @RequestBody PaymentRequest request) {
        try {
            BookingEntity bookingInfo =bookingService.makeTransaction(bookingId, request);
            return new ResponseEntity<>(bookingInfo, HttpStatus.CREATED);
        } catch (InvalidPaymentModeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ErrorResponse("Invalid mode of payment", 400));
        } catch (InvalidBookingIdException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(new ErrorResponse("Invalid Booking Id", 400));
        }
    }
}
