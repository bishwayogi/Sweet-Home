package com.sweethome.bookingservice.Model;

public class PaymentRequest {
    private String paymentMode;
    private String upiId;
    private String cardNumber;
    private Long bookingId;

    public PaymentRequest(String paymentMode,String upiId,String cardNumber,Long bookingId){
        this.paymentMode=paymentMode;
        this.upiId=upiId;
        this.cardNumber=cardNumber;
        this.bookingId=bookingId;
    }

    public String getPaymentMode() {
        return paymentMode;
    }

    public void setPaymentMode(String paymentMode) {
        this.paymentMode = paymentMode;
    }

    public Long getBookingId() {
        return bookingId;
    }

    public void setBookingId(Long bookingId) {
        this.bookingId = bookingId;
    }

    public String getCardNumber() {
        return cardNumber;
    }

    public void setCardNumber(String cardNumber) {
        this.cardNumber = cardNumber;
    }

    public String getUpiId() {
        return upiId;
    }

    public void setUpiId(String upiId) {
        this.upiId = upiId;
    }
}

