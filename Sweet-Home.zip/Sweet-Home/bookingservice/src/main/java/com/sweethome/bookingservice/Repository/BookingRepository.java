package com.sweethome.bookingservice.Repository;
import com.sweethome.bookingservice.Model.BookingEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface BookingRepository extends JpaRepository<BookingEntity, Long> {
    BookingEntity findById(long id);
}
