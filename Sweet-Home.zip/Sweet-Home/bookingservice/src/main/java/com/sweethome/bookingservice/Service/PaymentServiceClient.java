package com.sweethome.bookingservice.Service;

import com.sweethome.bookingservice.Model.PaymentRequest;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class PaymentServiceClient implements PaymentService {
    private final RestTemplate restTemplate;

    public PaymentServiceClient(RestTemplate restTemplate) {
        this.restTemplate = restTemplate;
    }

    @Override
    public Long processPayment(PaymentRequest paymentRequest) {
        // Send payment request to payment service
        String paymentServiceUrl = "http://localhost:9191/payment/transaction";
        return restTemplate.postForObject(paymentServiceUrl, paymentRequest, Long.class);
    }
}
