package com.sweethome.bookingservice.Service;
import com.sweethome.bookingservice.Model.*;
import com.sweethome.bookingservice.Repository.BookingRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.Random;
import org.springframework.transaction.annotation.Transactional;

@Service
public class BookingService {
    @Autowired
    private BookingRepository bookingRepository;

    @Autowired
    private PaymentService paymentService;

    @Transactional
    public BookingEntity bookRooms(BookingRequest request) {
        BookingEntity save=null;
        try {
            BookingEntity bookingInfo = new BookingEntity();
            bookingInfo.setFromDate(request.getFromDate());
            bookingInfo.setToDate(request.getToDate());
            bookingInfo.setAadharNumber(request.getAadharNumber());
            bookingInfo.setNumOfRooms(request.getNumOfRooms());
            bookingInfo.setBookedOn(LocalDate.now());

            List<String> roomNumbers = getRandomNumbers(request.getNumOfRooms());
            bookingInfo.setRoomNumbers(String.join(",", roomNumbers));

            bookingInfo.setRoomPrice(1000 * request.getNumOfRooms() * request.getFromDate().until(request.getToDate()).getDays());

            save = bookingRepository.save(bookingInfo);
        }
        catch (Exception ex){
            System.out.println(ex.getMessage());
        }
        return save;
    }


    public BookingEntity makeTransaction(Long bookingId, PaymentRequest paymentRequest) throws InvalidPaymentModeException, InvalidBookingIdException {
        Long transactionId=null;
        BookingEntity save=null;
        //try {
           if (!paymentRequest.getPaymentMode().equalsIgnoreCase("UPI") && !paymentRequest.getPaymentMode().equalsIgnoreCase("CARD")) {
               throw new InvalidPaymentModeException("Invalid mode of payment");
           }
           BookingEntity bookingInfo = getBookingById(bookingId);
           if (bookingInfo == null) {
               throw new InvalidBookingIdException("Invalid Booking Id");
           }


           PaymentRequest pr = new PaymentRequest(paymentRequest.getPaymentMode(), paymentRequest.getUpiId(), paymentRequest.getCardNumber(), paymentRequest.getBookingId());
            transactionId = paymentService.processPayment(pr); /* call payment service and get transactionId */


           bookingInfo.setTransactionId(transactionId);
            save=bookingRepository.save(bookingInfo);

            String message = "Booking confirmed for user with aadhaar number: "
                    + bookingInfo.getAadharNumber()
                    +    "    |    "
                    + "Here are the booking details:    " + bookingInfo.toString();

            System.out.println(message);

           return save;
//       }
//       catch (Exception ex){
//           System.out.println(ex.getMessage());
//       }
//        return save;
    }

    public BookingEntity getBookingById(long bookingId) {
        try{
        return bookingRepository.findById(bookingId);
        }
        catch(Exception Ex){
            System.out.println(Ex.getMessage());
        }
        return null;
    }
    public static ArrayList<String> getRandomNumbers(int count){
        Random rand = new Random();
        int upperBound = 100;
        ArrayList<String>numberList = new ArrayList<String>();

        for (int i=0; i<count; i++){
            numberList.add(String.valueOf(rand.nextInt(upperBound)));
        }

        return numberList;
    }

}
