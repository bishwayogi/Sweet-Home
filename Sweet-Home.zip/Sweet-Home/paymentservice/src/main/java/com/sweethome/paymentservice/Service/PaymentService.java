package com.sweethome.paymentservice.Service;

import com.sweethome.paymentservice.Model.PaymentRequest;
import com.sweethome.paymentservice.Model.TransactionDetailsEntity;
import com.sweethome.paymentservice.Model.TransactionNotFoundException;
import com.sweethome.paymentservice.Repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class PaymentService {

    @Autowired
    private TransactionRepository transactionRepository;

    public Long processPayment(PaymentRequest paymentRequest) {
        TransactionDetailsEntity transactionDetails = new TransactionDetailsEntity();
        try {
            transactionDetails.setPaymentMode(paymentRequest.getPaymentMode());
            transactionDetails.setBookingId(paymentRequest.getBookingId());
            transactionDetails.setUpiId(paymentRequest.getUpiId());
            transactionDetails.setCardNumber(paymentRequest.getCardNumber());

            // Save the transaction details
            transactionDetails = transactionRepository.save(transactionDetails);
        }
        catch(Exception ex){
            System.out.println(ex.getMessage());
        }
        return transactionDetails.getTransactionId();
    }

    public TransactionDetailsEntity getTransactionDetails(Long transactionId) {
        // Retrieve transaction details from the database using transactionId
        return transactionRepository.findById(transactionId)
                .orElseThrow(() -> new TransactionNotFoundException("Transaction not found with id: " + transactionId));
    }
}

