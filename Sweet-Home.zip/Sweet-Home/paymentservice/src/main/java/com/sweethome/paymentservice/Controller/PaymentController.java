package com.sweethome.paymentservice.Controller;

import com.sweethome.paymentservice.Model.PaymentRequest;
import com.sweethome.paymentservice.Model.TransactionDetailsEntity;
import com.sweethome.paymentservice.Service.PaymentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/payment")
public class PaymentController {

    @Autowired
    private PaymentService paymentService;

    @GetMapping
    public ResponseEntity<String> getHelloMessage() {
        return ResponseEntity.status(HttpStatus.OK).body("Hello!");
    }

    @PostMapping("/transaction")
    public ResponseEntity<Long> performTransaction(@RequestBody PaymentRequest paymentRequest) {
        Long transactionId = paymentService.processPayment(paymentRequest);
        return new ResponseEntity<>(transactionId, HttpStatus.CREATED);
    }

    @GetMapping("/transaction/{transactionId}")
    public ResponseEntity<TransactionDetailsEntity> getTransactionDetails(@PathVariable Long transactionId) {
        TransactionDetailsEntity transactionDetails = paymentService.getTransactionDetails(transactionId);
        return ResponseEntity.ok(transactionDetails);
    }
}

